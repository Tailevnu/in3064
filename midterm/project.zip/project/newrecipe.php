<?php
include "connection.php";
?>

<html>
<head>
    <title>Recipe Management</title>
    <meta charset="utf-8">
</head>
<body>
<div>
    <div>
        <h2>Add New Recipe</h2>
        <form action="" method="POST" enctype="multipart/form-data">
            <div>
                <label for="recipe_name">Recipe Name:</label>
                <input type="text" name="recipe_name" placeholder="Enter recipe name">
            </div>
            <div>
                <label for="recipe_image">Recipe Image:</label>
                <input type="file" name="recipe_image" accept="image/*">
            </div>
            <div>
                <label for="cook_time">Cooking Time (minutes):</label>
                <input type="number" name="cook_time" placeholder="Enter cooking time">
            </div>
            <div>
                <label for="instructions">Instructions:</label>
                <textarea name="instructions" rows="5" placeholder="Enter cooking instructions"></textarea>
            </div>
            
            <h3>Ingredients</h3>
            <div id="ingredient-list">
                <div class="ingredient-item">
                    <input type="text" name="ingredient_name[]" placeholder="Ingredient name">
                    <input type="text" name="quantity[]" placeholder="Quantity">
                </div>
            </div>
            <button type="button" onclick="addIngredient()">+ Add Ingredient</button>
            
            <br><br>
            <button type="submit" name="insert">Insert</button>
        </form>
    </div>
</div>

<script>
function addIngredient() {
    const container = document.getElementById('ingredient-list');
    const div = document.createElement('div');
    div.className = 'ingredient-item';
    div.innerHTML = 
        `<input type="text" name="ingredient_name[]" placeholder="Ingredient name">
         <input type="text" name="quantity[]" placeholder="Quantity">`;
    container.appendChild(div);
}
</script>
</body>

<?php
// Assuming session and user_id handling is moved to a separate file or handled elsewhere for simplicity
// For this example, hardcode or assume user_id=1; in production, restore session logic
$user_id = 1; // Placeholder; restore proper session/user_id logic as needed

if (isset($_POST["insert"])) {
    $recipe_name = $_POST['recipe_name'];
    $instructions = $_POST['instructions'];
    $cook_time = $_POST['cook_time'];
    
    // Handle image upload
    $recipe_image = '';
    if (isset($_FILES['recipe_image']) && $_FILES['recipe_image']['error'] == 0) {
        $target_dir = "uploads/";
        if (!is_dir($target_dir)) mkdir($target_dir);
        $recipe_image = $target_dir . basename($_FILES["recipe_image"]["name"]);
        move_uploaded_file($_FILES["recipe_image"]["tmp_name"], $recipe_image);
    }

    // Insert recipe
    mysqli_query($con, "INSERT INTO recipes (user_id, recipe_name, recipe_image, instructions, cook_time) 
                        VALUES ('$user_id', '$recipe_name', '$recipe_image', '$instructions', '$cook_time')");
    $recipe_id = mysqli_insert_id($con);

    // Insert ingredients
    if (!empty($_POST['ingredient_name'])) {
        foreach($_POST['ingredient_name'] as $i => $ingredient) {
            $quantity = $_POST['quantity'][$i];
            if ($ingredient && $quantity) {
                mysqli_query($con, "INSERT INTO ingredients (recipe_id, ingredient_name, quantity) 
                                    VALUES ('$recipe_id', '$ingredient', '$quantity')");
            }
        }
    }
    ?>
    <script type="text/javascript">
        window.location.href = window.location.href;
    </script>
    <?php
}
?>
</html>