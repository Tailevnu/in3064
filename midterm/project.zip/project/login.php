//login 
<!DOCTYPE html>
<html>
<meta charset="utf-8">
<head>
    <title>User login and Registration</title>

</head>
<body>

    <div>
        <div>
            <div>
               <div>
                   <h2>Login Here</h2>
                   <form action="validation.php" method="post">
                   <div>
                       <label>Username</label>
                       <label>
                           <input type="text" name="username" required>
                       </label>
                   </div>
                   <div>
                       <label>Password</label>
                       <label>
                           <input type="password" name="password" required>
                       </label>
                   </div>
                   <button type="submit">Login</button>
                   </form>
               </div>
                <div>
                    <h2>Registration Here</h2>
                    <form action="registration.php" method="post">
                        <div>
                            <label>Username</label>
                            <label>
                                <input type="text" name="username" required>
                            </label>
                        </div>
                        <div>
                            <label>Password</label>
                            <label>
                                <input type="password" name="password" required>
                            </label>
                        </div>
                        <div>
                            <label>Email</label>
                            <label>
                                <input type="email" name="email" required>
                            </label>
                        </div>
                         <div>
                            <label>Phone Number</label>
                            <label>
                                <input type="text" name="phone" required>
                            </label>
                        </div>                       
                        <button type="submit">Register</button>
                    </form>

                </div>

            </div>


        </div>


    </div>


</body>

</html>
