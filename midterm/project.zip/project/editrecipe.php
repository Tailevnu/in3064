<?php
include "connection.php";

$id = $_GET["id"];

$res = mysqli_query($con, "SELECT * FROM recipes WHERE recipe_id=$id");
while ($row = mysqli_fetch_array($res)) {
    $recipe_name = $row["recipe_name"];
    $recipe_image = $row["recipe_image"];
    $cook_time = $row["cook_time"];
    $instructions = $row["instructions"];
}

$ing_res = mysqli_query($con, "SELECT * FROM ingredients WHERE recipe_id=$id");
?>

<html lang="en">
<head>
    <title>Edit Recipe</title>
    <meta charset="utf-8">
</head>
<body>
<div>
    <div>
        <h2>Edit Recipe</h2>
        <form action="" method="post" enctype="multipart/form-data">
            <div>
                <label for="recipe_name">Recipe Name:</label>
                <input type="text" id="recipe_name" name="recipe_name" value="<?php echo $recipe_name; ?>">
            </div>
            <div>
                <label>Current Image:</label><br>
                <img src="<?php echo $recipe_image; ?>" width="150">
            </div>
            <div>
                <label for="recipe_image">Change Image:</label>
                <input type="file" id="recipe_image" name="recipe_image">
            </div>
            <div>
                <label for="cook_time">Cooking Time (minutes):</label>
                <input type="number" id="cook_time" name="cook_time" value="<?php echo $cook_time; ?>">
            </div>
            <div>
                <label for="instructions">Instructions:</label>
                <textarea id="instructions" name="instructions" rows="5"><?php echo $instructions; ?></textarea>
            </div>
            
            <h3>Ingredients</h3>
            <div id="ingredient-list">
                <?php while($ing = mysqli_fetch_array($ing_res)): ?>
                <div class="ingredient-item">
                    <input type="text" name="ingredient_name[]" value="<?php echo $ing['ingredient_name']; ?>">
                    <input type="text" name="quantity[]" value="<?php echo $ing['quantity']; ?>">
                </div>
                <?php endwhile; ?>
            </div>
            <button type="button" onclick="addIngredient()">+ Add Ingredient</button>
            
            <br><br>
            <button type="submit" name="update">Update</button>
        </form>
    </div>
</div>

<script>
function addIngredient() {
    const container = document.getElementById('ingredient-list');
    const div = document.createElement('div');
    div.className = 'ingredient-item';
    div.innerHTML = 
        `<input type="text" name="ingredient_name[]" placeholder="Ingredient name">
         <input type="text" name="quantity[]" placeholder="Quantity">`;
    container.appendChild(div);
}
</script>
</body>

<?php
if (isset($_POST["update"])) {
    // Handle new image upload if provided
    $new_image = $recipe_image; // Keep old image by default
    if (isset($_FILES['recipe_image']) && $_FILES['recipe_image']['error'] == 0) {
        $target_dir = "uploads/";
        $new_image = $target_dir . basename($_FILES["recipe_image"]["name"]);
        move_uploaded_file($_FILES["recipe_image"]["tmp_name"], $new_image);
    }
    
    mysqli_query($con, "UPDATE recipes 
        SET recipe_name='$_POST[recipe_name]',
            recipe_image='$new_image',
            instructions='$_POST[instructions]',
            cook_time='$_POST[cook_time]'
        WHERE recipe_id=$id");

    // Delete old ingredients and insert new/updated ones
    mysqli_query($con, "DELETE FROM ingredients WHERE recipe_id=$id");  
    if (!empty($_POST['ingredient_name'])) {
        foreach($_POST['ingredient_name'] as $i => $ingredient) {
            $quantity = $_POST['quantity'][$i];
            if ($ingredient && $quantity) {
                mysqli_query($con, "INSERT INTO ingredients (recipe_id, ingredient_name, quantity) 
                        VALUES ('$id', '$ingredient', '$quantity')");
            }
        }
    }
    ?>
    <script type="text/javascript">
        window.location = "home.php"; // Assuming home.php is the index/list page
    </script>
    <?php
}
?>
</html>