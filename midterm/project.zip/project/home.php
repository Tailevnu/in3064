<?php
session_start();
include "connection.php";

// Check if user is logged in
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit;
}

$username = $_SESSION['username'];

// Get user id from database
$query = "SELECT user_id FROM users WHERE username = '$username'";
$result = mysqli_query($con, $query);
$user = mysqli_fetch_assoc($result);
$user_id = $user['user_id'];

// Get all recipes for this user
$query = "SELECT * FROM recipes WHERE user_id = '$user_id'";
$result = mysqli_query($con, $query);
?>

<!DOCTYPE html>
<html>
<head>
    <title>My Recipe Book</title>
</head>
<body>
    <h1>Welcome <?php echo $username; ?></h1>
    <p>
        <a href="newrecipe.php">Add New Recipe</a> | 
        <a href="logout.php">Logout</a>
    </p>

    <h2>Your Recipes</h2>
    <table border="1">
        <tr>
            <th>Image</th>
            <th>Name</th>
            <th>Cooking Time</th>
            <th>Ingredients</th>
            <th>Instructions</th>
            <th>Actions</th>
        </tr>

        <?php
        // Show recipes if any exist
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                
                // Show recipe image
                echo "<td>";
                if (!empty($row['recipe_image'])) {
                    echo "<img src='{$row['recipe_image']}' width='100' height='80'>";
                } else {
                    echo "<img src='noimage.png' width='100' height='80'>";
                }
                echo "</td>";

                // Show recipe details
                echo "<td>{$row['recipe_name']}</td>";
                echo "<td>{$row['cook_time']} min</td>";

                // Get ingredients for this recipe
                echo "<td>";
                $ing_query = "SELECT * FROM ingredients WHERE recipe_id = {$row['recipe_id']}";
                $ing_result = mysqli_query($con, $ing_query);
                
                if (mysqli_num_rows($ing_result) > 0) {
                    echo "<ul>";
                    while ($ing = mysqli_fetch_assoc($ing_result)) {
                        echo "<li>{$ing['ingredient_name']} - {$ing['quantity']}</li>";
                    }
                    echo "</ul>";
                } else {
                    echo "No ingredients";
                }
                echo "</td>";

                echo "<td>{$row['instructions']}</td>";

                // Edit and Delete buttons
                echo "<td>
                    <a href='editrecipe.php?id={$row['recipe_id']}'>Edit</a> |
                    <a href='deleterecipe.php?id={$row['recipe_id']}' 
                       onclick='return confirm(\"Delete this recipe?\");'>Delete</a>
                </td>";
                
                echo "</tr>";
            }
        } else {
            echo "<tr><td>You have no recipes yet</td></tr>";
        }
        ?>
    </table>
</body>
</html>
